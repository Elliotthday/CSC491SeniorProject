﻿namespace SeniorProject_CSC490_
{
    partial class BundleLimitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BundleLimitForm));
            this.CancelButtonBundleLimit = new System.Windows.Forms.Button();
            this.OkayButton = new System.Windows.Forms.Button();
            this.BundleLimitSet = new System.Windows.Forms.TextBox();
            this.ErrorFieldBundleLimit = new System.Windows.Forms.TextBox();
            this.BundlelimitLabel2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CancelButtonBundleLimit
            // 
            this.CancelButtonBundleLimit.BackColor = System.Drawing.SystemColors.Menu;
            this.CancelButtonBundleLimit.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelButtonBundleLimit.ForeColor = System.Drawing.Color.Red;
            this.CancelButtonBundleLimit.Location = new System.Drawing.Point(243, 102);
            this.CancelButtonBundleLimit.Name = "CancelButtonBundleLimit";
            this.CancelButtonBundleLimit.Size = new System.Drawing.Size(83, 29);
            this.CancelButtonBundleLimit.TabIndex = 0;
            this.CancelButtonBundleLimit.Text = "Cancel";
            this.CancelButtonBundleLimit.UseVisualStyleBackColor = false;
            this.CancelButtonBundleLimit.Click += new System.EventHandler(this.CancelButtonBundleLimit_Click);
            // 
            // OkayButton
            // 
            this.OkayButton.BackColor = System.Drawing.SystemColors.Menu;
            this.OkayButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OkayButton.Location = new System.Drawing.Point(154, 102);
            this.OkayButton.Name = "OkayButton";
            this.OkayButton.Size = new System.Drawing.Size(83, 29);
            this.OkayButton.TabIndex = 1;
            this.OkayButton.Text = "Ok";
            this.OkayButton.UseVisualStyleBackColor = false;
            this.OkayButton.Click += new System.EventHandler(this.OkayButton_Click);
            // 
            // BundleLimitSet
            // 
            this.BundleLimitSet.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundleLimitSet.Location = new System.Drawing.Point(189, 55);
            this.BundleLimitSet.Name = "BundleLimitSet";
            this.BundleLimitSet.Size = new System.Drawing.Size(100, 25);
            this.BundleLimitSet.TabIndex = 0;
            this.BundleLimitSet.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BundleLimitSet_KeyDown);
            // 
            // ErrorFieldBundleLimit
            // 
            this.ErrorFieldBundleLimit.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ErrorFieldBundleLimit.Location = new System.Drawing.Point(110, 152);
            this.ErrorFieldBundleLimit.Name = "ErrorFieldBundleLimit";
            this.ErrorFieldBundleLimit.ReadOnly = true;
            this.ErrorFieldBundleLimit.Size = new System.Drawing.Size(258, 22);
            this.ErrorFieldBundleLimit.TabIndex = 3;
            // 
            // BundlelimitLabel2
            // 
            this.BundlelimitLabel2.AutoSize = true;
            this.BundlelimitLabel2.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundlelimitLabel2.Location = new System.Drawing.Point(53, 55);
            this.BundlelimitLabel2.Name = "BundlelimitLabel2";
            this.BundlelimitLabel2.Size = new System.Drawing.Size(121, 20);
            this.BundlelimitLabel2.TabIndex = 4;
            this.BundlelimitLabel2.Text = "Bundle Limit (lbs):";
            // 
            // BundleLimitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(463, 224);
            this.Controls.Add(this.BundlelimitLabel2);
            this.Controls.Add(this.ErrorFieldBundleLimit);
            this.Controls.Add(this.BundleLimitSet);
            this.Controls.Add(this.OkayButton);
            this.Controls.Add(this.CancelButtonBundleLimit);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BundleLimitForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bundle Limit";
            this.Load += new System.EventHandler(this.BundleLimitForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CancelButtonBundleLimit;
        private System.Windows.Forms.Button OkayButton;
        private System.Windows.Forms.TextBox BundleLimitSet;
        private System.Windows.Forms.TextBox ErrorFieldBundleLimit;
        private System.Windows.Forms.Label BundlelimitLabel2;
    }
}