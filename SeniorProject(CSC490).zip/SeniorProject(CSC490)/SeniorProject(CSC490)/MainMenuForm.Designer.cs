﻿namespace SeniorProject_CSC490_
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.ShimMenuButton = new System.Windows.Forms.Button();
            this.TimerMenuButton = new System.Windows.Forms.Button();
            this.CatMenuButton = new System.Windows.Forms.Button();
            this.WeatherMenuButton = new System.Windows.Forms.Button();
            this.BoredMenuButton = new System.Windows.Forms.Button();
            this.QuitMainMenuButton = new System.Windows.Forms.Button();
            this.MainMenuTime = new System.Windows.Forms.Label();
            this.MainMenuTimer = new System.Windows.Forms.Timer(this.components);
            this.MainMenuDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ShimMenuButton
            // 
            this.ShimMenuButton.BackColor = System.Drawing.SystemColors.Menu;
            this.ShimMenuButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ShimMenuButton.BackgroundImage")));
            this.ShimMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ShimMenuButton.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShimMenuButton.ForeColor = System.Drawing.Color.Black;
            this.ShimMenuButton.Location = new System.Drawing.Point(64, 232);
            this.ShimMenuButton.Name = "ShimMenuButton";
            this.ShimMenuButton.Size = new System.Drawing.Size(237, 68);
            this.ShimMenuButton.TabIndex = 0;
            this.ShimMenuButton.Text = "Shim App";
            this.ShimMenuButton.UseVisualStyleBackColor = false;
            this.ShimMenuButton.Click += new System.EventHandler(this.ShimMenuButton_Click);
            // 
            // TimerMenuButton
            // 
            this.TimerMenuButton.BackColor = System.Drawing.SystemColors.Menu;
            this.TimerMenuButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TimerMenuButton.BackgroundImage")));
            this.TimerMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TimerMenuButton.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimerMenuButton.Location = new System.Drawing.Point(326, 232);
            this.TimerMenuButton.Name = "TimerMenuButton";
            this.TimerMenuButton.Size = new System.Drawing.Size(237, 68);
            this.TimerMenuButton.TabIndex = 1;
            this.TimerMenuButton.Text = "Timer App";
            this.TimerMenuButton.UseVisualStyleBackColor = false;
            this.TimerMenuButton.Click += new System.EventHandler(this.TimerMenuButton_Click);
            // 
            // CatMenuButton
            // 
            this.CatMenuButton.BackColor = System.Drawing.SystemColors.Menu;
            this.CatMenuButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CatMenuButton.BackgroundImage")));
            this.CatMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.CatMenuButton.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatMenuButton.Location = new System.Drawing.Point(326, 324);
            this.CatMenuButton.Name = "CatMenuButton";
            this.CatMenuButton.Size = new System.Drawing.Size(237, 68);
            this.CatMenuButton.TabIndex = 2;
            this.CatMenuButton.Text = "Cat Fact App";
            this.CatMenuButton.UseVisualStyleBackColor = false;
            this.CatMenuButton.Click += new System.EventHandler(this.CatMenuButton_Click);
            // 
            // WeatherMenuButton
            // 
            this.WeatherMenuButton.BackColor = System.Drawing.SystemColors.Menu;
            this.WeatherMenuButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WeatherMenuButton.BackgroundImage")));
            this.WeatherMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WeatherMenuButton.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WeatherMenuButton.Location = new System.Drawing.Point(64, 324);
            this.WeatherMenuButton.Name = "WeatherMenuButton";
            this.WeatherMenuButton.Size = new System.Drawing.Size(237, 68);
            this.WeatherMenuButton.TabIndex = 3;
            this.WeatherMenuButton.Text = "Weather App";
            this.WeatherMenuButton.UseVisualStyleBackColor = false;
            this.WeatherMenuButton.Click += new System.EventHandler(this.WeatherMenuButton_Click);
            // 
            // BoredMenuButton
            // 
            this.BoredMenuButton.BackColor = System.Drawing.SystemColors.Menu;
            this.BoredMenuButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BoredMenuButton.BackgroundImage")));
            this.BoredMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BoredMenuButton.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoredMenuButton.Location = new System.Drawing.Point(64, 410);
            this.BoredMenuButton.Name = "BoredMenuButton";
            this.BoredMenuButton.Size = new System.Drawing.Size(237, 68);
            this.BoredMenuButton.TabIndex = 4;
            this.BoredMenuButton.Text = "Bored App";
            this.BoredMenuButton.UseVisualStyleBackColor = false;
            this.BoredMenuButton.Click += new System.EventHandler(this.BoredMenuButton_Click);
            // 
            // QuitMainMenuButton
            // 
            this.QuitMainMenuButton.BackColor = System.Drawing.SystemColors.Menu;
            this.QuitMainMenuButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("QuitMainMenuButton.BackgroundImage")));
            this.QuitMainMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.QuitMainMenuButton.Font = new System.Drawing.Font("Franklin Gothic Book", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuitMainMenuButton.ForeColor = System.Drawing.Color.Red;
            this.QuitMainMenuButton.Location = new System.Drawing.Point(326, 410);
            this.QuitMainMenuButton.Name = "QuitMainMenuButton";
            this.QuitMainMenuButton.Size = new System.Drawing.Size(237, 68);
            this.QuitMainMenuButton.TabIndex = 5;
            this.QuitMainMenuButton.Text = "Quit";
            this.QuitMainMenuButton.UseVisualStyleBackColor = false;
            this.QuitMainMenuButton.Click += new System.EventHandler(this.QuitMainMenuButton_Click);
            // 
            // MainMenuTime
            // 
            this.MainMenuTime.AutoSize = true;
            this.MainMenuTime.Font = new System.Drawing.Font("Franklin Gothic Book", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuTime.ForeColor = System.Drawing.Color.Black;
            this.MainMenuTime.Location = new System.Drawing.Point(49, 51);
            this.MainMenuTime.Name = "MainMenuTime";
            this.MainMenuTime.Size = new System.Drawing.Size(175, 85);
            this.MainMenuTime.TabIndex = 6;
            this.MainMenuTime.Text = "Time";
            // 
            // MainMenuTimer
            // 
            this.MainMenuTimer.Interval = 1000;
            this.MainMenuTimer.Tick += new System.EventHandler(this.MainMenuTimer_Tick);
            // 
            // MainMenuDate
            // 
            this.MainMenuDate.AutoSize = true;
            this.MainMenuDate.Font = new System.Drawing.Font("Franklin Gothic Book", 25.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuDate.ForeColor = System.Drawing.Color.Black;
            this.MainMenuDate.Location = new System.Drawing.Point(54, 138);
            this.MainMenuDate.Name = "MainMenuDate";
            this.MainMenuDate.Size = new System.Drawing.Size(106, 49);
            this.MainMenuDate.TabIndex = 7;
            this.MainMenuDate.Text = "Date";
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(621, 555);
            this.Controls.Add(this.MainMenuDate);
            this.Controls.Add(this.MainMenuTime);
            this.Controls.Add(this.QuitMainMenuButton);
            this.Controls.Add(this.BoredMenuButton);
            this.Controls.Add(this.WeatherMenuButton);
            this.Controls.Add(this.CatMenuButton);
            this.Controls.Add(this.TimerMenuButton);
            this.Controls.Add(this.ShimMenuButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Widget App";
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ShimMenuButton;
        private System.Windows.Forms.Button TimerMenuButton;
        private System.Windows.Forms.Button CatMenuButton;
        private System.Windows.Forms.Button WeatherMenuButton;
        private System.Windows.Forms.Button BoredMenuButton;
        private System.Windows.Forms.Button QuitMainMenuButton;
        private System.Windows.Forms.Label MainMenuTime;
        private System.Windows.Forms.Timer MainMenuTimer;
        private System.Windows.Forms.Label MainMenuDate;
    }
}

