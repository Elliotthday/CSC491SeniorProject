﻿namespace SeniorProject_CSC490_
{
    partial class WeatherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WeatherForm));
            this.TitleWeatherApp = new System.Windows.Forms.Label();
            this.GetWeatherButton = new System.Windows.Forms.Button();
            this.WeatherTextBox = new System.Windows.Forms.TextBox();
            this.WeatherPictureBox = new System.Windows.Forms.PictureBox();
            this.CityTextBox = new System.Windows.Forms.TextBox();
            this.CityLabel = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.HelpWeatherApp = new System.Windows.Forms.ToolStripMenuItem();
            this.QuitWeatherApp = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.WeatherPictureBox)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TitleWeatherApp
            // 
            this.TitleWeatherApp.AutoSize = true;
            this.TitleWeatherApp.Cursor = System.Windows.Forms.Cursors.Default;
            this.TitleWeatherApp.Font = new System.Drawing.Font("Franklin Gothic Book", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleWeatherApp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TitleWeatherApp.Location = new System.Drawing.Point(379, 51);
            this.TitleWeatherApp.Name = "TitleWeatherApp";
            this.TitleWeatherApp.Size = new System.Drawing.Size(356, 75);
            this.TitleWeatherApp.TabIndex = 0;
            this.TitleWeatherApp.Text = "Weather App";
            // 
            // GetWeatherButton
            // 
            this.GetWeatherButton.BackColor = System.Drawing.SystemColors.Menu;
            this.GetWeatherButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GetWeatherButton.Location = new System.Drawing.Point(85, 237);
            this.GetWeatherButton.Name = "GetWeatherButton";
            this.GetWeatherButton.Size = new System.Drawing.Size(570, 52);
            this.GetWeatherButton.TabIndex = 1;
            this.GetWeatherButton.Text = "Get Weather";
            this.GetWeatherButton.UseVisualStyleBackColor = false;
            this.GetWeatherButton.Click += new System.EventHandler(this.GetWeatherButton_Click);
            // 
            // WeatherTextBox
            // 
            this.WeatherTextBox.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WeatherTextBox.Location = new System.Drawing.Point(85, 316);
            this.WeatherTextBox.Multiline = true;
            this.WeatherTextBox.Name = "WeatherTextBox";
            this.WeatherTextBox.ReadOnly = true;
            this.WeatherTextBox.Size = new System.Drawing.Size(570, 251);
            this.WeatherTextBox.TabIndex = 2;
            // 
            // WeatherPictureBox
            // 
            this.WeatherPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("WeatherPictureBox.Image")));
            this.WeatherPictureBox.Location = new System.Drawing.Point(723, 253);
            this.WeatherPictureBox.Name = "WeatherPictureBox";
            this.WeatherPictureBox.Size = new System.Drawing.Size(369, 314);
            this.WeatherPictureBox.TabIndex = 3;
            this.WeatherPictureBox.TabStop = false;
            // 
            // CityTextBox
            // 
            this.CityTextBox.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityTextBox.Location = new System.Drawing.Point(179, 187);
            this.CityTextBox.Name = "CityTextBox";
            this.CityTextBox.Size = new System.Drawing.Size(204, 22);
            this.CityTextBox.TabIndex = 0;
            this.CityTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CityTextBox_KeyDown);
            // 
            // CityLabel
            // 
            this.CityLabel.AutoSize = true;
            this.CityLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityLabel.Location = new System.Drawing.Point(81, 187);
            this.CityLabel.Name = "CityLabel";
            this.CityLabel.Size = new System.Drawing.Size(82, 21);
            this.CityLabel.TabIndex = 5;
            this.CityLabel.Text = "Enter City:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HelpWeatherApp,
            this.QuitWeatherApp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1148, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // HelpWeatherApp
            // 
            this.HelpWeatherApp.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HelpWeatherApp.Name = "HelpWeatherApp";
            this.HelpWeatherApp.Size = new System.Drawing.Size(52, 24);
            this.HelpWeatherApp.Text = "Help";
            this.HelpWeatherApp.Click += new System.EventHandler(this.HelpWeatherApp_Click);
            // 
            // QuitWeatherApp
            // 
            this.QuitWeatherApp.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuitWeatherApp.ForeColor = System.Drawing.Color.Red;
            this.QuitWeatherApp.Name = "QuitWeatherApp";
            this.QuitWeatherApp.Size = new System.Drawing.Size(48, 24);
            this.QuitWeatherApp.Text = "Quit";
            this.QuitWeatherApp.Click += new System.EventHandler(this.QuitWeatherApp_Click);
            // 
            // WeatherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1148, 641);
            this.Controls.Add(this.CityLabel);
            this.Controls.Add(this.CityTextBox);
            this.Controls.Add(this.WeatherPictureBox);
            this.Controls.Add(this.WeatherTextBox);
            this.Controls.Add(this.GetWeatherButton);
            this.Controls.Add(this.TitleWeatherApp);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "WeatherForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Weather App";
            ((System.ComponentModel.ISupportInitialize)(this.WeatherPictureBox)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleWeatherApp;
        private System.Windows.Forms.Button GetWeatherButton;
        private System.Windows.Forms.TextBox WeatherTextBox;
        private System.Windows.Forms.PictureBox WeatherPictureBox;
        private System.Windows.Forms.TextBox CityTextBox;
        private System.Windows.Forms.Label CityLabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem HelpWeatherApp;
        private System.Windows.Forms.ToolStripMenuItem QuitWeatherApp;
    }
}