﻿namespace SeniorProject_CSC490_
{
    partial class CatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CatForm));
            this.CatTextBox = new System.Windows.Forms.TextBox();
            this.CatFactButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CatPictureBox = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveOverCat = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveAsCat = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.QuitCatApp = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.CatPictureBox)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CatTextBox
            // 
            this.CatTextBox.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatTextBox.Location = new System.Drawing.Point(69, 259);
            this.CatTextBox.Multiline = true;
            this.CatTextBox.Name = "CatTextBox";
            this.CatTextBox.ReadOnly = true;
            this.CatTextBox.Size = new System.Drawing.Size(416, 175);
            this.CatTextBox.TabIndex = 2;
            this.CatTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CatTextBox_KeyDown);
            // 
            // CatFactButton
            // 
            this.CatFactButton.BackColor = System.Drawing.SystemColors.Menu;
            this.CatFactButton.Font = new System.Drawing.Font("Franklin Gothic Book", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatFactButton.ForeColor = System.Drawing.Color.Black;
            this.CatFactButton.Location = new System.Drawing.Point(69, 169);
            this.CatFactButton.Name = "CatFactButton";
            this.CatFactButton.Size = new System.Drawing.Size(416, 84);
            this.CatFactButton.TabIndex = 3;
            this.CatFactButton.Text = "Get Cat Fact";
            this.CatFactButton.UseVisualStyleBackColor = false;
            this.CatFactButton.Click += new System.EventHandler(this.CatFactButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Book", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(244, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 75);
            this.label1.TabIndex = 4;
            this.label1.Text = "Cat Fact App";
            // 
            // CatPictureBox
            // 
            this.CatPictureBox.BackColor = System.Drawing.SystemColors.Window;
            this.CatPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.CatPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("CatPictureBox.Image")));
            this.CatPictureBox.Location = new System.Drawing.Point(533, 169);
            this.CatPictureBox.Name = "CatPictureBox";
            this.CatPictureBox.Size = new System.Drawing.Size(219, 225);
            this.CatPictureBox.TabIndex = 5;
            this.CatPictureBox.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.QuitCatApp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(780, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveOverCat,
            this.SaveAsCat});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(45, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // SaveOverCat
            // 
            this.SaveOverCat.Enabled = false;
            this.SaveOverCat.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveOverCat.Name = "SaveOverCat";
            this.SaveOverCat.Size = new System.Drawing.Size(143, 26);
            this.SaveOverCat.Text = "Save";
            this.SaveOverCat.Click += new System.EventHandler(this.SaveOverCat_Click);
            // 
            // SaveAsCat
            // 
            this.SaveAsCat.Enabled = false;
            this.SaveAsCat.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveAsCat.Name = "SaveAsCat";
            this.SaveAsCat.Size = new System.Drawing.Size(143, 26);
            this.SaveAsCat.Text = "Save As";
            this.SaveAsCat.Click += new System.EventHandler(this.SaveAsCat_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // QuitCatApp
            // 
            this.QuitCatApp.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuitCatApp.ForeColor = System.Drawing.Color.Red;
            this.QuitCatApp.Name = "QuitCatApp";
            this.QuitCatApp.Size = new System.Drawing.Size(48, 24);
            this.QuitCatApp.Text = "Quit";
            this.QuitCatApp.Click += new System.EventHandler(this.QuitCatApp_Click);
            // 
            // CatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(780, 499);
            this.Controls.Add(this.CatPictureBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CatFactButton);
            this.Controls.Add(this.CatTextBox);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "CatForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cat App";
            ((System.ComponentModel.ISupportInitialize)(this.CatPictureBox)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CatFactButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox CatPictureBox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SaveOverCat;
        private System.Windows.Forms.ToolStripMenuItem SaveAsCat;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem QuitCatApp;
        protected internal System.Windows.Forms.TextBox CatTextBox;
    }
}