﻿namespace SeniorProject_CSC490_
{
    partial class SaveCat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SaveCat));
            this.SaveCatTitle = new System.Windows.Forms.Label();
            this.FileNameCat = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SaveButtonCat = new System.Windows.Forms.Button();
            this.SaveQuitButtonCat = new System.Windows.Forms.Button();
            this.ErrorFieldSaveCat = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // SaveCatTitle
            // 
            this.SaveCatTitle.AutoSize = true;
            this.SaveCatTitle.Font = new System.Drawing.Font("Franklin Gothic Book", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveCatTitle.Location = new System.Drawing.Point(205, 35);
            this.SaveCatTitle.Name = "SaveCatTitle";
            this.SaveCatTitle.Size = new System.Drawing.Size(171, 36);
            this.SaveCatTitle.TabIndex = 5;
            this.SaveCatTitle.Text = "Save Append";
            // 
            // FileNameCat
            // 
            this.FileNameCat.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FileNameCat.Location = new System.Drawing.Point(155, 88);
            this.FileNameCat.Name = "FileNameCat";
            this.FileNameCat.Size = new System.Drawing.Size(294, 22);
            this.FileNameCat.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 21);
            this.label2.TabIndex = 7;
            this.label2.Text = "File Name:";
            // 
            // SaveButtonCat
            // 
            this.SaveButtonCat.BackColor = System.Drawing.SystemColors.Menu;
            this.SaveButtonCat.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButtonCat.Location = new System.Drawing.Point(220, 140);
            this.SaveButtonCat.Name = "SaveButtonCat";
            this.SaveButtonCat.Size = new System.Drawing.Size(75, 36);
            this.SaveButtonCat.TabIndex = 8;
            this.SaveButtonCat.Text = "Save";
            this.SaveButtonCat.UseVisualStyleBackColor = false;
            this.SaveButtonCat.Click += new System.EventHandler(this.SaveButtonCat_Click);
            // 
            // SaveQuitButtonCat
            // 
            this.SaveQuitButtonCat.BackColor = System.Drawing.SystemColors.Menu;
            this.SaveQuitButtonCat.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveQuitButtonCat.ForeColor = System.Drawing.Color.Red;
            this.SaveQuitButtonCat.Location = new System.Drawing.Point(301, 140);
            this.SaveQuitButtonCat.Name = "SaveQuitButtonCat";
            this.SaveQuitButtonCat.Size = new System.Drawing.Size(75, 36);
            this.SaveQuitButtonCat.TabIndex = 9;
            this.SaveQuitButtonCat.Text = "Cancel";
            this.SaveQuitButtonCat.UseVisualStyleBackColor = false;
            this.SaveQuitButtonCat.Click += new System.EventHandler(this.SaveQuitButtonCat_Click);
            // 
            // ErrorFieldSaveCat
            // 
            this.ErrorFieldSaveCat.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ErrorFieldSaveCat.Location = new System.Drawing.Point(155, 215);
            this.ErrorFieldSaveCat.Name = "ErrorFieldSaveCat";
            this.ErrorFieldSaveCat.ReadOnly = true;
            this.ErrorFieldSaveCat.Size = new System.Drawing.Size(294, 22);
            this.ErrorFieldSaveCat.TabIndex = 10;
            // 
            // SaveCat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(575, 312);
            this.Controls.Add(this.ErrorFieldSaveCat);
            this.Controls.Add(this.SaveQuitButtonCat);
            this.Controls.Add(this.SaveButtonCat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FileNameCat);
            this.Controls.Add(this.SaveCatTitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SaveCat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cat Fact Save";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SaveCatTitle;
        private System.Windows.Forms.TextBox FileNameCat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button SaveButtonCat;
        private System.Windows.Forms.Button SaveQuitButtonCat;
        private System.Windows.Forms.TextBox ErrorFieldSaveCat;
    }
}