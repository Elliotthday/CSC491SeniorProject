﻿namespace SeniorProject_CSC490_
{
    partial class ShimForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShimForm));
            this.ShimAppTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RunningTotalLabel = new System.Windows.Forms.Label();
            this.RunningTotal = new System.Windows.Forms.Label();
            this.CountShimLabel = new System.Windows.Forms.Label();
            this.ShimCount = new System.Windows.Forms.Label();
            this.BundleUntilLimitLabel = new System.Windows.Forms.Label();
            this.BundleLimitCount = new System.Windows.Forms.Label();
            this.BundleLimitLabel = new System.Windows.Forms.Label();
            this.InputField = new System.Windows.Forms.TextBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.BundleLimit = new System.Windows.Forms.Label();
            this.StandardDevLabel = new System.Windows.Forms.Label();
            this.UndoButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.ErrorField = new System.Windows.Forms.TextBox();
            this.StandardDev = new System.Windows.Forms.Label();
            this.MaxWeightLabel = new System.Windows.Forms.Label();
            this.MaxWeight = new System.Windows.Forms.Label();
            this.AverageWeightLabel = new System.Windows.Forms.Label();
            this.MinWeightLabel = new System.Windows.Forms.Label();
            this.AverageWeight = new System.Windows.Forms.Label();
            this.MinWeight = new System.Windows.Forms.Label();
            this.OtherInfoLabel = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveAsButton = new System.Windows.Forms.ToolStripMenuItem();
            this.PrintButton = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpButtonShim = new System.Windows.Forms.ToolStripMenuItem();
            this.BundleLimitButton = new System.Windows.Forms.ToolStripMenuItem();
            this.QuitButtonShim = new System.Windows.Forms.ToolStripMenuItem();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ShimAppTitle
            // 
            this.ShimAppTitle.AutoSize = true;
            this.ShimAppTitle.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShimAppTitle.Location = new System.Drawing.Point(219, 77);
            this.ShimAppTitle.Name = "ShimAppTitle";
            this.ShimAppTitle.Size = new System.Drawing.Size(245, 75);
            this.ShimAppTitle.TabIndex = 0;
            this.ShimAppTitle.Text = "Shim App";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(119, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Weight of Shim To Add:";
            // 
            // RunningTotalLabel
            // 
            this.RunningTotalLabel.AutoSize = true;
            this.RunningTotalLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunningTotalLabel.Location = new System.Drawing.Point(97, 308);
            this.RunningTotalLabel.Name = "RunningTotalLabel";
            this.RunningTotalLabel.Size = new System.Drawing.Size(176, 20);
            this.RunningTotalLabel.TabIndex = 2;
            this.RunningTotalLabel.Text = "Running Total Weight (lbs):";
            // 
            // RunningTotal
            // 
            this.RunningTotal.AutoSize = true;
            this.RunningTotal.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunningTotal.Location = new System.Drawing.Point(281, 308);
            this.RunningTotal.Name = "RunningTotal";
            this.RunningTotal.Size = new System.Drawing.Size(18, 20);
            this.RunningTotal.TabIndex = 3;
            this.RunningTotal.Text = "0";
            // 
            // CountShimLabel
            // 
            this.CountShimLabel.AutoSize = true;
            this.CountShimLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountShimLabel.Location = new System.Drawing.Point(165, 345);
            this.CountShimLabel.Name = "CountShimLabel";
            this.CountShimLabel.Size = new System.Drawing.Size(111, 20);
            this.CountShimLabel.TabIndex = 4;
            this.CountShimLabel.Text = "Count of Shims:\r\n";
            // 
            // ShimCount
            // 
            this.ShimCount.AutoSize = true;
            this.ShimCount.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShimCount.Location = new System.Drawing.Point(281, 345);
            this.ShimCount.Name = "ShimCount";
            this.ShimCount.Size = new System.Drawing.Size(18, 20);
            this.ShimCount.TabIndex = 5;
            this.ShimCount.Text = "0";
            // 
            // BundleUntilLimitLabel
            // 
            this.BundleUntilLimitLabel.AutoSize = true;
            this.BundleUntilLimitLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundleUntilLimitLabel.Location = new System.Drawing.Point(130, 389);
            this.BundleUntilLimitLabel.Name = "BundleUntilLimitLabel";
            this.BundleUntilLimitLabel.Size = new System.Drawing.Size(145, 20);
            this.BundleUntilLimitLabel.TabIndex = 6;
            this.BundleUntilLimitLabel.Text = "Until Bundle Full (lbs):";
            // 
            // BundleLimitCount
            // 
            this.BundleLimitCount.AutoSize = true;
            this.BundleLimitCount.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundleLimitCount.Location = new System.Drawing.Point(281, 389);
            this.BundleLimitCount.Name = "BundleLimitCount";
            this.BundleLimitCount.Size = new System.Drawing.Size(18, 20);
            this.BundleLimitCount.TabIndex = 7;
            this.BundleLimitCount.Text = "5";
            // 
            // BundleLimitLabel
            // 
            this.BundleLimitLabel.AutoSize = true;
            this.BundleLimitLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundleLimitLabel.Location = new System.Drawing.Point(154, 427);
            this.BundleLimitLabel.Name = "BundleLimitLabel";
            this.BundleLimitLabel.Size = new System.Drawing.Size(121, 20);
            this.BundleLimitLabel.TabIndex = 8;
            this.BundleLimitLabel.Text = "Bundle Limit (lbs):";
            // 
            // InputField
            // 
            this.InputField.Font = new System.Drawing.Font("Franklin Gothic Book", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputField.Location = new System.Drawing.Point(281, 193);
            this.InputField.Name = "InputField";
            this.InputField.Size = new System.Drawing.Size(133, 22);
            this.InputField.TabIndex = 1;
            this.InputField.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InputField_KeyDown);
            // 
            // AddButton
            // 
            this.AddButton.BackColor = System.Drawing.SystemColors.Menu;
            this.AddButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddButton.Location = new System.Drawing.Point(281, 236);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(133, 39);
            this.AddButton.TabIndex = 9;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = false;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click_1);
            // 
            // BundleLimit
            // 
            this.BundleLimit.AutoSize = true;
            this.BundleLimit.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundleLimit.Location = new System.Drawing.Point(281, 427);
            this.BundleLimit.Name = "BundleLimit";
            this.BundleLimit.Size = new System.Drawing.Size(18, 20);
            this.BundleLimit.TabIndex = 10;
            this.BundleLimit.Text = "5";
            // 
            // StandardDevLabel
            // 
            this.StandardDevLabel.AutoSize = true;
            this.StandardDevLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StandardDevLabel.Location = new System.Drawing.Point(107, 638);
            this.StandardDevLabel.Name = "StandardDevLabel";
            this.StandardDevLabel.Size = new System.Drawing.Size(166, 20);
            this.StandardDevLabel.TabIndex = 11;
            this.StandardDevLabel.Text = "Standard Deviation (lbs):";
            // 
            // UndoButton
            // 
            this.UndoButton.BackColor = System.Drawing.SystemColors.Menu;
            this.UndoButton.Enabled = false;
            this.UndoButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UndoButton.Location = new System.Drawing.Point(221, 496);
            this.UndoButton.Name = "UndoButton";
            this.UndoButton.Size = new System.Drawing.Size(113, 39);
            this.UndoButton.TabIndex = 18;
            this.UndoButton.Text = "Undo Last";
            this.UndoButton.UseVisualStyleBackColor = false;
            this.UndoButton.Click += new System.EventHandler(this.UndoButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.BackColor = System.Drawing.SystemColors.Menu;
            this.ResetButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetButton.ForeColor = System.Drawing.Color.Red;
            this.ResetButton.Location = new System.Drawing.Point(342, 496);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(113, 39);
            this.ResetButton.TabIndex = 19;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = false;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // ErrorField
            // 
            this.ErrorField.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ErrorField.Location = new System.Drawing.Point(134, 759);
            this.ErrorField.Name = "ErrorField";
            this.ErrorField.ReadOnly = true;
            this.ErrorField.Size = new System.Drawing.Size(454, 25);
            this.ErrorField.TabIndex = 20;
            // 
            // StandardDev
            // 
            this.StandardDev.AutoSize = true;
            this.StandardDev.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StandardDev.Location = new System.Drawing.Point(281, 638);
            this.StandardDev.Name = "StandardDev";
            this.StandardDev.Size = new System.Drawing.Size(18, 20);
            this.StandardDev.TabIndex = 21;
            this.StandardDev.Text = "0";
            // 
            // MaxWeightLabel
            // 
            this.MaxWeightLabel.AutoSize = true;
            this.MaxWeightLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxWeightLabel.Location = new System.Drawing.Point(157, 699);
            this.MaxWeightLabel.Name = "MaxWeightLabel";
            this.MaxWeightLabel.Size = new System.Drawing.Size(116, 20);
            this.MaxWeightLabel.TabIndex = 22;
            this.MaxWeightLabel.Text = "Max Weight (lbs):";
            // 
            // MaxWeight
            // 
            this.MaxWeight.AutoSize = true;
            this.MaxWeight.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxWeight.Location = new System.Drawing.Point(281, 699);
            this.MaxWeight.Name = "MaxWeight";
            this.MaxWeight.Size = new System.Drawing.Size(18, 20);
            this.MaxWeight.TabIndex = 23;
            this.MaxWeight.Text = "0\r\n";
            // 
            // AverageWeightLabel
            // 
            this.AverageWeightLabel.AutoSize = true;
            this.AverageWeightLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageWeightLabel.Location = new System.Drawing.Point(398, 638);
            this.AverageWeightLabel.Name = "AverageWeightLabel";
            this.AverageWeightLabel.Size = new System.Drawing.Size(141, 20);
            this.AverageWeightLabel.TabIndex = 24;
            this.AverageWeightLabel.Text = "Average Weight (lbs):";
            // 
            // MinWeightLabel
            // 
            this.MinWeightLabel.AutoSize = true;
            this.MinWeightLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinWeightLabel.Location = new System.Drawing.Point(426, 699);
            this.MinWeightLabel.Name = "MinWeightLabel";
            this.MinWeightLabel.Size = new System.Drawing.Size(113, 20);
            this.MinWeightLabel.TabIndex = 25;
            this.MinWeightLabel.Text = "Min Weight (lbs):";
            // 
            // AverageWeight
            // 
            this.AverageWeight.AutoSize = true;
            this.AverageWeight.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageWeight.Location = new System.Drawing.Point(545, 638);
            this.AverageWeight.Name = "AverageWeight";
            this.AverageWeight.Size = new System.Drawing.Size(18, 20);
            this.AverageWeight.TabIndex = 26;
            this.AverageWeight.Text = "0";
            // 
            // MinWeight
            // 
            this.MinWeight.AutoSize = true;
            this.MinWeight.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinWeight.Location = new System.Drawing.Point(545, 699);
            this.MinWeight.Name = "MinWeight";
            this.MinWeight.Size = new System.Drawing.Size(18, 20);
            this.MinWeight.TabIndex = 27;
            this.MinWeight.Text = "0";
            // 
            // OtherInfoLabel
            // 
            this.OtherInfoLabel.AutoSize = true;
            this.OtherInfoLabel.Font = new System.Drawing.Font("Franklin Gothic Book", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OtherInfoLabel.Location = new System.Drawing.Point(226, 575);
            this.OtherInfoLabel.Name = "OtherInfoLabel";
            this.OtherInfoLabel.Size = new System.Drawing.Size(225, 36);
            this.OtherInfoLabel.TabIndex = 28;
            this.OtherInfoLabel.Text = "Other Information";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.HelpButtonShim,
            this.BundleLimitButton,
            this.QuitButtonShim});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(697, 28);
            this.menuStrip1.TabIndex = 29;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveAsButton,
            this.PrintButton});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(45, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // SaveAsButton
            // 
            this.SaveAsButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveAsButton.Name = "SaveAsButton";
            this.SaveAsButton.Size = new System.Drawing.Size(143, 26);
            this.SaveAsButton.Text = "Save As";
            this.SaveAsButton.Click += new System.EventHandler(this.SaveAsButton_Click);
            // 
            // PrintButton
            // 
            this.PrintButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintButton.Name = "PrintButton";
            this.PrintButton.Size = new System.Drawing.Size(143, 26);
            this.PrintButton.Text = "Print";
            this.PrintButton.Click += new System.EventHandler(this.PrintButton_Click);
            // 
            // HelpButtonShim
            // 
            this.HelpButtonShim.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HelpButtonShim.Name = "HelpButtonShim";
            this.HelpButtonShim.Size = new System.Drawing.Size(52, 24);
            this.HelpButtonShim.Text = "Help";
            this.HelpButtonShim.Click += new System.EventHandler(this.HelpButtonShim_Click);
            // 
            // BundleLimitButton
            // 
            this.BundleLimitButton.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BundleLimitButton.Name = "BundleLimitButton";
            this.BundleLimitButton.Size = new System.Drawing.Size(101, 24);
            this.BundleLimitButton.Text = "Bundle Limit";
            this.BundleLimitButton.Click += new System.EventHandler(this.BundleLimitButton_Click);
            // 
            // QuitButtonShim
            // 
            this.QuitButtonShim.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuitButtonShim.ForeColor = System.Drawing.Color.Red;
            this.QuitButtonShim.Name = "QuitButtonShim";
            this.QuitButtonShim.Size = new System.Drawing.Size(48, 24);
            this.QuitButtonShim.Text = "Quit";
            this.QuitButtonShim.Click += new System.EventHandler(this.QuitButtonShim_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // ShimForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(697, 859);
            this.Controls.Add(this.OtherInfoLabel);
            this.Controls.Add(this.MinWeight);
            this.Controls.Add(this.AverageWeight);
            this.Controls.Add(this.MinWeightLabel);
            this.Controls.Add(this.AverageWeightLabel);
            this.Controls.Add(this.MaxWeight);
            this.Controls.Add(this.MaxWeightLabel);
            this.Controls.Add(this.StandardDev);
            this.Controls.Add(this.ErrorField);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.UndoButton);
            this.Controls.Add(this.StandardDevLabel);
            this.Controls.Add(this.BundleLimit);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.InputField);
            this.Controls.Add(this.BundleLimitLabel);
            this.Controls.Add(this.BundleLimitCount);
            this.Controls.Add(this.BundleUntilLimitLabel);
            this.Controls.Add(this.ShimCount);
            this.Controls.Add(this.CountShimLabel);
            this.Controls.Add(this.RunningTotal);
            this.Controls.Add(this.RunningTotalLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ShimAppTitle);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ShimForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shim App";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ShimAppTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label RunningTotalLabel;
        private System.Windows.Forms.Label RunningTotal;
        private System.Windows.Forms.Label CountShimLabel;
        private System.Windows.Forms.Label ShimCount;
        private System.Windows.Forms.Label BundleUntilLimitLabel;
        private System.Windows.Forms.Label BundleLimitLabel;
        private System.Windows.Forms.TextBox InputField;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Label StandardDevLabel;
        private System.Windows.Forms.Button UndoButton;
        private System.Windows.Forms.TextBox ErrorField;
        private System.Windows.Forms.Label StandardDev;
        private System.Windows.Forms.Label MaxWeightLabel;
        private System.Windows.Forms.Label MaxWeight;
        private System.Windows.Forms.Label AverageWeightLabel;
        private System.Windows.Forms.Label MinWeightLabel;
        private System.Windows.Forms.Label AverageWeight;
        private System.Windows.Forms.Label MinWeight;
        private System.Windows.Forms.Label OtherInfoLabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SaveAsButton;
        private System.Windows.Forms.ToolStripMenuItem PrintButton;
        private System.Windows.Forms.ToolStripMenuItem HelpButtonShim;
        private System.Windows.Forms.ToolStripMenuItem BundleLimitButton;
        private System.Windows.Forms.ToolStripMenuItem QuitButtonShim;
        protected internal System.Windows.Forms.Label BundleLimitCount;
        protected internal System.Windows.Forms.Label BundleLimit;
        protected internal System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}